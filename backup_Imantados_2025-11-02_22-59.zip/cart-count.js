(() => {
  function getCount() {
    try {
      const arr = JSON.parse(localStorage.getItem('emojiCart') || '[]');
      if (!Array.isArray(arr)) return 0;
      return arr.reduce((acc, i) => acc + (i.quantity || 1), 0);
    } catch {
      return 0;
    }
  }

  function updateCount() {
    const els = document.querySelectorAll('[data-cart-count]');
    const c = getCount();
    els.forEach(el => { el.textContent = String(c); });
  }

  window.addEventListener('storage', updateCount);
  window.addEventListener('cart-updated', updateCount);
  document.addEventListener('DOMContentLoaded', updateCount);
})();