const http = require('http');
const fs = require('fs');
const path = require('path');

const port = process.env.PORT ? Number(process.env.PORT) : 4173;
const root = __dirname;

const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm',
};

function send(res, status, headers, body) {
  res.writeHead(status, headers);
  res.end(body);
}

function serveFile(filePath, res) {
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      return send(res, 404, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Not Found');
    }
    const ext = path.extname(filePath).toLowerCase();
    const type = types[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  try {
    const url = decodeURI(req.url.split('?')[0]);
    // API para listar emojis
    if (url === '/api/emojis') {
      const dir = path.join(root, 'assets', 'EMOJIS');
      fs.readdir(dir, (err, files) => {
        if (err) {
          return send(res, 500, { 'Content-Type': 'application/json; charset=utf-8' }, JSON.stringify({ error: 'Failed to read emojis directory' }));
        }
        const allowed = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif']);
        const list = files
          .filter(f => allowed.has(path.extname(f).toLowerCase()))
          .map(f => ({ name: f, url: `/assets/EMOJIS/${encodeURI(f)}` }));
        return send(res, 200, { 'Content-Type': 'application/json; charset=utf-8' }, JSON.stringify(list));
      });
      return;
    }
    let filePath = path.join(root, url);
    if (url === '/' || url === '') {
      filePath = path.join(root, 'index.html');
    }
    // evita directory traversal
    if (!filePath.startsWith(root)) {
      return send(res, 403, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Forbidden');
    }
    serveFile(filePath, res);
  } catch (e) {
    send(res, 500, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Internal Server Error');
  }
});

server.listen(port, () => {
  console.log(`Static server running at http://localhost:${port}/`);
});