(() => {
  const qs = (sel) => document.querySelector(sel);

  // Firebase Auth – provedores
  const requireAuthConfig = () => {
    if (!window.Auth || !window.Auth.isReady()) {
      alert('Firebase não configurado. Copie auth.config.example.js para auth.config.js e preencha FIREBASE_CONFIG.');
      return false;
    }
    return true;
  };

  const afterLogin = (user) => {
    if (!user) return;
    try {
      localStorage.setItem('authUser', JSON.stringify({ uid: user.uid, email: user.email, name: user.displayName, phone: user.phoneNumber }));
    } catch {}
    window.location.href = 'index.html';
  };

  qs('.auth-google')?.addEventListener('click', async () => {
    if (!requireAuthConfig()) return;
    try { const res = await window.Auth.signInWithGoogle(); afterLogin(res.user); }
    catch (e) { alert('Erro no Google: ' + e.message); }
  });

  qs('.auth-apple')?.addEventListener('click', async () => {
    if (!requireAuthConfig()) return;
    try { const res = await window.Auth.signInWithApple(); afterLogin(res.user); }
    catch (e) { alert('Erro no Apple: ' + e.message); }
  });

  qs('.auth-microsoft')?.addEventListener('click', async () => {
    if (!requireAuthConfig()) return;
    try { const res = await window.Auth.signInWithMicrosoft(); afterLogin(res.user); }
    catch (e) { alert('Erro no Microsoft: ' + e.message); }
  });

  // Telefone – fluxo de SMS
  const phoneLogin = qs('#phone-login');
  const phoneNumberInput = qs('#phone-number');
  const phoneCodeInput = qs('#phone-code');
  let confirmationResult = null;

  qs('.auth-phone')?.addEventListener('click', () => {
    phoneLogin.hidden = !phoneLogin.hidden;
    if (!phoneLogin.hidden) phoneNumberInput?.focus();
  });

  qs('#phone-send')?.addEventListener('click', async () => {
    if (!requireAuthConfig()) return;
    const phone = (phoneNumberInput?.value || '').trim();
    if (!/^\+\d{7,}$/.test(phone)) { alert('Informe um telefone válido no formato internacional.'); return; }
    try {
      confirmationResult = await window.Auth.startPhoneSignIn(phone, 'recaptcha-container');
      alert('Código enviado por SMS. Digite para verificar.');
      phoneCodeInput?.focus();
    } catch (e) {
      alert('Erro ao enviar código: ' + e.message);
    }
  });

  qs('#phone-verify')?.addEventListener('click', async () => {
    if (!requireAuthConfig()) return;
    if (!confirmationResult) { alert('Primeiro envie o código ao seu telefone.'); return; }
    const code = (phoneCodeInput?.value || '').trim();
    if (!/^[0-9]{4,8}$/.test(code)) { alert('Código inválido.'); return; }
    try { const res = await window.Auth.confirmPhoneCode(confirmationResult, code); afterLogin(res.user); }
    catch (e) { alert('Erro ao verificar código: ' + e.message); }
  });

  // Email login
  const emailForm = qs('#auth-email-form');
  const emailInput = qs('#auth-email');
  emailForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = (emailInput?.value || '').trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      alert('Informe um e-mail válido.');
      return;
    }
    // Placeholder: aqui você pode enviar código mágico/link de login
    alert(`Enviaremos um link para: ${email}`);
  });

  // Navegação entre seções
  const signupSection = qs('#signup-section');
  const recoverSection = qs('#recover-section');
  const showMain = () => { signupSection.hidden = true; recoverSection.hidden = true; };
  const showSignup = () => { signupSection.hidden = false; recoverSection.hidden = true; };
  const showRecover = () => { signupSection.hidden = true; recoverSection.hidden = false; };

  qs('#link-signup')?.addEventListener('click', showSignup);
  qs('#link-recover')?.addEventListener('click', showRecover);
  qs('#signup-back')?.addEventListener('click', showMain);
  qs('#recover-back')?.addEventListener('click', showMain);

  // Form de cadastro – placeholder
  const signupForm = qs('#signup-form');
  signupForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = (qs('#signup-name')?.value || '').trim();
    const email = (qs('#signup-email')?.value || '').trim();
    const pwd = (qs('#signup-password')?.value || '').trim();
    if (!name || !email || !pwd) { alert('Preencha todos os campos.'); return; }
    alert(`Conta criada para ${name}. Confirme no e-mail: ${email}`);
    showMain();
  });

  // Form de recuperação – placeholder
  const recoverForm = qs('#recover-form');
  recoverForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = (qs('#recover-email')?.value || '').trim();
    if (!email) { alert('Informe seu e-mail.'); return; }
    alert(`Se existir conta, enviaremos um link para: ${email}`);
    showMain();
  });
})();