// Inicialização e provedores do Firebase Auth (compat)
// Requer: firebase-app-compat.js, firebase-auth-compat.js e (opcional) auth.config.js

(function () {
  const hasConfig = typeof window.FIREBASE_CONFIG !== 'undefined';
  let app = null;
  let auth = null;
  let phoneAppVerifier = null;

  function init() {
    if (!hasConfig) return false;
    if (!app) {
      app = firebase.initializeApp(window.FIREBASE_CONFIG);
      auth = firebase.auth();
    }
    return true;
  }

  function ensureInit() {
    const ok = init();
    if (!ok) throw new Error('Firebase não configurado. Crie auth.config.js com FIREBASE_CONFIG.');
  }

  function providerFor(name) {
    switch (name) {
      case 'google':
        return new firebase.auth.GoogleAuthProvider();
      case 'apple':
        return new firebase.auth.OAuthProvider('apple.com');
      case 'microsoft':
        return new firebase.auth.OAuthProvider('microsoft.com');
      default:
        throw new Error('Provider desconhecido: ' + name);
    }
  }

  async function signInWithProvider(name) {
    ensureInit();
    const provider = providerFor(name);
    // Opcional: força popup
    return auth.signInWithPopup(provider);
  }

  function getPhoneVerifier(containerId) {
    ensureInit();
    if (!phoneAppVerifier) {
      phoneAppVerifier = new firebase.auth.RecaptchaVerifier(containerId, {
        size: 'invisible',
      });
    }
    return phoneAppVerifier;
  }

  async function startPhoneSignIn(phoneNumber, containerId) {
    const verifier = getPhoneVerifier(containerId);
    return auth.signInWithPhoneNumber(phoneNumber, verifier);
  }

  function confirmPhoneCode(confirmationResult, code) {
    return confirmationResult.confirm(code);
  }

  function onStateChange(cb) {
    ensureInit();
    return auth.onAuthStateChanged(cb);
  }

  // Exponho uma API simples no window
  window.Auth = {
    isReady: () => hasConfig,
    init,
    signInWithGoogle: () => signInWithProvider('google'),
    signInWithApple: () => signInWithProvider('apple'),
    signInWithMicrosoft: () => signInWithProvider('microsoft'),
    startPhoneSignIn,
    confirmPhoneCode,
    onStateChange,
  };

  // Inicializa e persiste estado básico
  try {
    if (init()) {
      onStateChange((user) => {
        const data = user
          ? { uid: user.uid, email: user.email, name: user.displayName, phone: user.phoneNumber }
          : null;
        try {
          localStorage.setItem('authUser', JSON.stringify(data));
        } catch (e) {}
      });
    }
  } catch (e) {
    console.warn('Auth init aviso:', e.message);
  }
})();