(() => {
  const uploadBtn = document.getElementById('uploadBtn');
  const fileInput = document.getElementById('fileInput');
  const gallery = document.getElementById('gallery');
  const addToCartBtn = document.getElementById('addToCartBtn');
  const previewBtn = document.getElementById('previewBtn');

  let lastObjectUrl = null;

  // Conversão pixel-milímetro (ajustada para 2.2 px/mm)
  const PX_PER_MM = 2.2;
  // Conversão para centímetros
  const PX_PER_CM = PX_PER_MM * 10; // 22 px/cm
  // Preço agora por cm² (mantendo o mesmo custo físico de 0,003 R$/mm²)
  const PRICE_PER_CM2 = 0.20; // R$ por cm²
  // Limites em centímetros (3–15 cm)
  const MIN_SIZE_CM = 3;
  const MAX_SIZE_CM = 15;

  // Calcula escala mínima e máxima baseada no tamanho da imagem
  const getScaleLimits = (imgWidth, imgHeight) => {
    const maxDimPx = Math.max(imgWidth, imgHeight);
    const minScale = (MIN_SIZE_CM * PX_PER_CM) / maxDimPx;
    const maxScale = (MAX_SIZE_CM * PX_PER_CM) / maxDimPx;
    return { minScale: Math.max(0.1, minScale), maxScale: Math.min(5, maxScale) };
  };

  // Converte tamanho em pixels para milímetros (mantido para lógicas internas como contorno)
  const pxToMm = (px) => px / PX_PER_MM;
  const mmToPx = (mm) => mm * PX_PER_MM;
  // Conversão em centímetros para exibição e lógica de dimensionamento
  const pxToCm = (px) => px / PX_PER_CM;
  const cmToPx = (cm) => cm * PX_PER_CM;

  // Utilitário para carregar script externo (html2canvas)
  function loadScriptOnce(src) {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) { resolve(); return; }
      const s = document.createElement('script');
      s.src = src; s.async = true; s.crossOrigin = 'anonymous';
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Falha ao carregar dependência'));
      document.head.appendChild(s);
    });
  }

  // Efeito ripple no clique
  function addRipple(e) {
    if (!uploadBtn) return;
    const rect = uploadBtn.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const ripple = document.createElement('span');
    ripple.className = 'ripple';
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    uploadBtn.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  }

  // Verificar se os elementos existem antes de adicionar listeners
  let openingPicker = false;
  // Cooldown curto após o seletor ser fechado/alterado para evitar reabertura
  let pickerRecentlyClosed = false;
  // Estado para saber se o seletor está aberto via click programático
  let pickerOpen = false;
  // Dedupe de arquivos já carregados (por nome|tamanho|lastModified)
  const loadedFileKeys = new Set();
  const fileKey = (f) => `${f.name}|${f.size}|${f.lastModified}`;
  if (uploadBtn) {
    uploadBtn.addEventListener('pointerdown', addRipple);
    uploadBtn.addEventListener('pointerup', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (openingPicker || pickerRecentlyClosed) return;
      openingPicker = true;
      try { fileInput.value = ''; } catch {}
      // Abrir seletor e desfocar o botão para evitar novo clique ao retornar do diálogo
      pickerOpen = true;
      fileInput.click();
      try { uploadBtn.blur(); } catch {}
      setTimeout(() => { openingPicker = false; }, 1200);
    }, { passive: false });
  }
  // Botão de Preview
  if (previewBtn) {
    previewBtn.addEventListener('click', async () => {
      try {
        document.body.classList.add('previewing');
        // Garante dependência para renderizar DOM como imagem
        if (!window.html2canvas) {
          await loadScriptOnce('https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js');
        }
        // Aguarda o layout aplicar as classes ocultas
        await new Promise(r => setTimeout(r, 60));

        // Calcula total atual para exibição no preview
        let totalSum = 0;
        Array.from(document.querySelectorAll('.image-wrap')).forEach((wrap) => {
          const img = wrap.querySelector('.user-image');
          if (!img) return;
          const r = img.getBoundingClientRect();
          const widthCm = pxToCm(r.width);
          const heightCm = pxToCm(r.height);
          const area = widthCm * heightCm;
          totalSum += area * PRICE_PER_CM2;
        });
        const formatBRL = (v) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

        const canvas = await window.html2canvas(document.body, {
          backgroundColor: null,
          scale: window.devicePixelRatio || 1,
          useCORS: true,
          ignoreElements: (el) => el.classList && el.classList.contains('preview-overlay')
        });
        const dataUrl = canvas.toDataURL('image/png');

        // Monta modal com a imagem capturada
        const overlay = document.createElement('div');
        overlay.className = 'preview-overlay';
        overlay.innerHTML = `
          <div class="preview-modal">
            <img class="preview-image" alt="Pré-visualização" src="${dataUrl}">
            <div class="preview-actions">
              <div class="total">Total: ${formatBRL(totalSum)}</div>
              <button class="btn btn-back" type="button">Voltar e editar</button>
              <button class="btn btn-approve" type="button">Ok, ir ao carrinho</button>
            </div>
          </div>`;
        document.body.appendChild(overlay);
        const closeOverlay = () => { overlay.remove(); document.body.classList.remove('previewing'); };
        overlay.querySelector('.btn-back').addEventListener('click', closeOverlay);
        overlay.querySelector('.btn-approve').addEventListener('click', () => {
          try { addAllImagesToCart(); } catch {}
          closeOverlay();
          window.location.href = 'carrinho.html';
        });
        // Fechar com ESC
        const onKey = (e) => { if (e.key === 'Escape') { closeOverlay(); window.removeEventListener('keydown', onKey); } };
        window.addEventListener('keydown', onKey);
      } catch (err) {
        console.error(err);
        document.body.classList.remove('previewing');
        showToast('Não foi possível gerar a pré-visualização.');
      }
    });
  }
  // CTA do header: abrir seletor de arquivos (mesma ação do botão flutuante)
  const ctaCreate = document.getElementById('cta-create');
  if (ctaCreate && fileInput) {
    ctaCreate.addEventListener('pointerup', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (openingPicker || pickerRecentlyClosed) return;
      openingPicker = true;
      try { fileInput.value = ''; } catch {}
      try { pickerOpen = true; fileInput.click(); } catch {}
      try { ctaCreate.blur(); } catch {}
      setTimeout(() => { openingPicker = false; }, 1200);
    }, { passive: false });
  }

  // CTA do avatar topo: mesma ação do cta-create
  const topAvatarCta = document.getElementById('top-avatar-cta');
  if (topAvatarCta && fileInput) {
    topAvatarCta.addEventListener('pointerup', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (openingPicker || pickerRecentlyClosed) return;
      openingPicker = true;
      try { fileInput.value = ''; } catch {}
      try { pickerOpen = true; fileInput.click(); } catch {}
      try { topAvatarCta.blur(); } catch {}
      setTimeout(() => { openingPicker = false; }, 1200);
    }, { passive: false });
  }

  // Utilitários de imagem
  const fitWithin = (w, h, max = 200) => {
    const ratio = Math.min(max / w, max / h, 1);
    return { w: Math.round(w * ratio), h: Math.round(h * ratio) };
  };

  // Thumbnail persistente (data URL) a partir de um <img>
  // Mantido dentro do escopo principal para ter acesso a helpers locais
  const makeThumbDataUrl = (imgEl, max = 220) => {
    try {
      const w = imgEl.naturalWidth || imgEl.width || 200;
      const h = imgEl.naturalHeight || imgEl.height || 200;
      const { w: tw, h: th } = fitWithin(w, h, max);
      const canvas = document.createElement('canvas');
      canvas.width = tw;
      canvas.height = th;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, tw, th);
      ctx.drawImage(imgEl, 0, 0, tw, th);
      return canvas.toDataURL('image/png');
    } catch {
      // Se houver erro (ex.: CORS/tainted), volta ao src original
      return imgEl.src;
    }
  };

  const loadImage = (url) => new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });

  const isDark = (r, g, b, thr = 35) => r < thr && g < thr && b < thr;
  const dist2 = (r1,g1,b1,r2,g2,b2) => {
    const dr = r1 - r2, dg = g1 - g2, db = b1 - b2;
    return dr*dr + dg*dg + db*db;
  };

  async function processImageVariants(url, max = 400, force = false) {
    try {
      const src = await loadImage(url);
      const { w, h } = fitWithin(src.naturalWidth || src.width, src.naturalHeight || src.height, max);
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(src, 0, 0, w, h);
      const imgData = ctx.getImageData(0, 0, w, h);
      const data = imgData.data;
      let didRemove = false;

      // Verificação prévia: remover fundo se a cor das bordas for praticamente uniforme (qualquer cor)
      const borderInfo = (() => {
        let total = 0;
        let rSum = 0, gSum = 0, bSum = 0;
        // amostragem com passo para performance
        const step = Math.max(1, Math.floor(Math.min(w, h) / 80));
        const add = (x,y) => {
          const i4 = (y * w + x) * 4;
          const a = data[i4 + 3];
          if (a <= 10) return;
          rSum += data[i4]; gSum += data[i4 + 1]; bSum += data[i4 + 2];
          total++;
        };
        for (let x = 0; x < w; x += step) { add(x, 0); add(x, h-1); }
        for (let y = 0; y < h; y += step) { add(0, y); add(w-1, y); }
        const mean = total ? { r: Math.round(rSum/total), g: Math.round(gSum/total), b: Math.round(bSum/total) } : { r:255,g:255,b:255 };
        let within = 0;
        const thr = 32; // tolerância de cor (euclidiana) ~ leve variação
        const thr2 = thr*thr;
        const count = () => {
          let cnt = 0, ok = 0;
          for (let x = 0; x < w; x += step) {
            for (const y of [0, h-1]) {
              const i4 = (y * w + x) * 4; if (data[i4 + 3] <= 10) continue; cnt++;
              if (dist2(data[i4], data[i4+1], data[i4+2], mean.r, mean.g, mean.b) <= thr2) ok++;
            }
          }
          for (let y = 0; y < h; y += step) {
            for (const x of [0, w-1]) {
              const i4 = (y * w + x) * 4; if (data[i4 + 3] <= 10) continue; cnt++;
              if (dist2(data[i4], data[i4+1], data[i4+2], mean.r, mean.g, mean.b) <= thr2) ok++;
            }
          }
          return { cnt, ok };
        };
        const { cnt, ok } = count();
        const ratio = cnt ? ok / cnt : 0;
        return { mean, ratio, thr2 };
      })();

      if (!force && borderInfo.ratio < 0.85) {
        return { processed: false };
      }

      // Flood fill por borda para remover regiões escuras conectadas às bordas
      const visited = new Uint8Array(w * h);
      const queue = [];
      const pushIfBg = (x, y) => {
        const idx = (y * w + x);
        if (visited[idx]) return;
        const i4 = idx * 4;
        const r = data[i4], g = data[i4 + 1], b = data[i4 + 2], a = data[i4 + 3];
        if (a > 10 && dist2(r,g,b,borderInfo.mean.r,borderInfo.mean.g,borderInfo.mean.b) <= borderInfo.thr2) {
          visited[idx] = 1;
          queue.push(idx);
        }
      };

      for (let x = 0; x < w; x++) { pushIfBg(x, 0); pushIfBg(x, h - 1); }
      for (let y = 0; y < h; y++) { pushIfBg(0, y); pushIfBg(w - 1, y); }

      const neighbors = (idx) => {
        const x = idx % w, y = (idx / w) | 0;
        const res = [];
        if (x > 0) res.push(idx - 1);
        if (x < w - 1) res.push(idx + 1);
        if (y > 0) res.push(idx - w);
        if (y < h - 1) res.push(idx + w);
        return res;
      };

      while (queue.length) {
        const idx = queue.shift();
        const i4 = idx * 4;
        if (data[i4 + 3] !== 0) didRemove = true;
        data[i4 + 3] = 0; // torna transparente
        for (const n of neighbors(idx)) {
          if (visited[n]) continue;
          const j4 = n * 4;
          const r = data[j4], g = data[j4 + 1], b = data[j4 + 2], a = data[j4 + 3];
          if (a > 10 && dist2(r,g,b,borderInfo.mean.r,borderInfo.mean.g,borderInfo.mean.b) <= borderInfo.thr2) {
            visited[n] = 1;
            queue.push(n);
          }
        }
      }

      // Guarda uma cópia do resultado sem contorno
      const baseData = new ImageData(new Uint8ClampedArray(imgData.data), w, h);

      // Cria contorno (estilo figurinha): dilatação da máscara alpha e diferença
      const alphaThr = 10;
      const thickness = Math.max(1, Math.round(1.14 * PX_PER_MM)); // espessura ~1.14mm em px (BG ON +15%)
      const size = w * h;
      const mask = new Uint8Array(size);
      for (let i = 0; i < size; i++) mask[i] = data[i * 4 + 3] > alphaThr ? 1 : 0;

      let dil = mask.slice();
      for (let t = 0; t < thickness; t++) {
        const next = dil.slice();
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const idx = y * w + x;
            if (dil[idx]) continue; // já é 1
            let hasNeighbor = false;
            for (let ny = y - 1; ny <= y + 1 && !hasNeighbor; ny++) {
              for (let nx = x - 1; nx <= x + 1 && !hasNeighbor; nx++) {
                if (nx === x && ny === y) continue;
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                if (dil[ny * w + nx]) hasNeighbor = true;
              }
            }
            if (hasNeighbor) next[idx] = 1;
          }
        }
        dil = next;
      }

      // outline = (dil && !mask) com antialias via blur da alfa do contorno
      let didOutline = false;
      const outline = new Uint8Array(size);
      for (let i = 0; i < size; i++) {
        if (dil[i] && !mask[i]) { outline[i] = 1; didOutline = true; }
      }

      // Função auxiliar: verifica se um pixel toca a máscara original (borda interna)
      const touchesMask = (idx) => {
        const x = idx % w, y = (idx / w) | 0;
        for (let ny = y - 1; ny <= y + 1; ny++) {
          for (let nx = x - 1; nx <= x + 1; nx++) {
            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
            if (mask[ny * w + nx]) return true;
          }
        }
        return false;
      };

      if (didOutline) {
        // 1) Alfa binária do contorno (0/255)
        let alphaA = new Uint16Array(size);
        for (let i = 0; i < size; i++) alphaA[i] = outline[i] ? 255 : 0;

        // 2) Duas passagens de blur 3x3 para suavizar a borda externa
        const blurPass = (src) => {
          const dst = new Uint16Array(size);
          for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
              let sum = 0, cnt = 0;
              for (let ny = y - 1; ny <= y + 1; ny++) {
                for (let nx = x - 1; nx <= x + 1; nx++) {
                  if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                  sum += src[ny * w + nx];
                  cnt++;
                }
              }
              dst[y * w + x] = Math.round(sum / cnt);
            }
          }
          return dst;
        };

        alphaA = blurPass(alphaA);
        alphaA = blurPass(alphaA);

        // 3) Pinta contorno branco com alfa suavizado, mantendo borda interna sólida
        for (let i = 0; i < size; i++) {
          if (!outline[i]) continue;
          const k = i * 4;
          let a = alphaA[i];
          if (touchesMask(i)) a = 255; // interno sólido
          if (a < 70) a = 70;          // evita sumiço do contorno
          data[k] = 255; data[k + 1] = 255; data[k + 2] = 255; data[k + 3] = a;
        }
      }

      // Endurece o alfa e remove semitransparência residual (mais agressivo)
      const hardThr = 96;

      // Pré-computa vizinhos transparentes (raio 2) para decontaminação de cor
      const hasTransparentNeighbor = new Uint8Array(size);
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const idx = y * w + x;
          const i4 = idx * 4;
          if (data[i4 + 3] === 0) continue;
          let nearTransparent = false;
          for (let ny = y - 2; ny <= y + 2 && !nearTransparent; ny++) {
            for (let nx = x - 2; nx <= x + 2 && !nearTransparent; nx++) {
              if (nx === x && ny === y) continue;
              if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
              const n4 = (ny * w + nx) * 4;
              if (data[n4 + 3] === 0) nearTransparent = true;
            }
          }
          if (nearTransparent) hasTransparentNeighbor[idx] = 1;
        }
      }

      for (let i = 0; i < size; i++) {
        const k = i * 4;
        const a = data[k + 3];
        // Para pixels do contorno, preserva o alfa suavizado (não endurece)
        if (outline[i]) { continue; }
        if (a <= hardThr) {
          data[k + 3] = 0; // totalmente transparente
        } else {
          data[k + 3] = 255; // totalmente opaco
          // Decontamina a borda para branco quando está adjacente ao transparente
          if (hasTransparentNeighbor[i]) {
            data[k] = 255; data[k + 1] = 255; data[k + 2] = 255;
          }
        }
      }

      // Gera dois blobs: sem contorno (baseData) e com contorno (imgData)
      ctx.putImageData(baseData, 0, 0);
      const blobNo = await new Promise((res) => canvas.toBlob(res, 'image/png'));
      ctx.putImageData(imgData, 0, 0);
      const blobWith = await new Promise((res) => canvas.toBlob(res, 'image/png'));
      return {
        processed: didRemove || didOutline,
        noOutlineUrl: blobNo ? URL.createObjectURL(blobNo) : undefined,
        outlineUrl: blobWith ? URL.createObjectURL(blobWith) : undefined,
      };
    } catch {
      return { processed: false };
    }
  }

  // Abrir imagem e centralizar
  function createImageWrap(originalUrl, displayUrl, index, isProcessed, variants) {
    const wrap = document.createElement('div');
    wrap.className = 'image-wrap';
    // deslocamento inicial leve para reduzir sobreposição
    const step = 18;
    wrap.style.setProperty('--drag-x', `${index * step}px`);
    wrap.style.setProperty('--drag-y', `${index * step}px`);
    wrap.style.setProperty('--scale', '1');
    // Espessura fixa do contorno em px (0.75mm)
    wrap.style.setProperty('--outline-px', `${0.75 * PX_PER_MM}px`);

    const img = document.createElement('img');
    img.className = 'user-image visible';
    img.alt = 'Imagem selecionada';
    img.src = displayUrl;
    if (isProcessed) img.classList.add('processed');
    img.draggable = false;

    // Indicadores (tamanho e preço lado a lado)
    const sizeIndicator = document.createElement('div');
    sizeIndicator.className = 'size-indicator';
    sizeIndicator.textContent = '0×0cm';

    const priceIndicator = document.createElement('div');
    priceIndicator.className = 'price-indicator';
    priceIndicator.textContent = 'R$ 0,00';

    const indicators = document.createElement('div');
    indicators.className = 'indicator-bar';
    // Preço à esquerda, tamanho à direita
    indicators.append(priceIndicator, sizeIndicator);

    // botão de fechar
    const close = document.createElement('button');
    close.className = 'close-btn';
    close.type = 'button';
    close.setAttribute('aria-label', 'Fechar imagem');
    close.textContent = '×';

    // Controles por imagem
    const ctrls = document.createElement('div');
    ctrls.className = 'controls';
    const btnBg = document.createElement('button');
    btnBg.className = 'ctrl-btn btn-bg';
    btnBg.type = 'button';
    btnBg.title = 'Remover/Restaurar fundo';
    btnBg.textContent = 'Fundo';
    const btnCt = document.createElement('button');
    btnCt.className = 'ctrl-btn btn-ct';
    btnCt.type = 'button';
    btnCt.title = 'Contorno branco on/off';
    btnCt.textContent = 'Contorno';
    const btnMinus = document.createElement('button');
    btnMinus.className = 'ctrl-btn btn-zoom-out';
    btnMinus.type = 'button';
    btnMinus.title = 'Diminuir';
    btnMinus.textContent = '−';
    const btnPlus = document.createElement('button');
    btnPlus.className = 'ctrl-btn btn-zoom-in';
    btnPlus.type = 'button';
    btnPlus.title = 'Aumentar';
    btnPlus.textContent = '+';
    ctrls.append(btnBg, btnCt, btnMinus, btnPlus);

    wrap.dataset.objurl = originalUrl;
    wrap.dataset.processedNo = variants?.noOutlineUrl || '';
    wrap.dataset.processedWith = variants?.outlineUrl || '';
    wrap.dataset.bg = isProcessed ? 'on' : 'off';
    wrap.dataset.ct = isProcessed ? 'on' : 'off';
    wrap.appendChild(img);
    wrap.appendChild(indicators);
    wrap.appendChild(ctrls);
    wrap.appendChild(close);

    // Função para atualizar o indicador de tamanho
    const updateSizeIndicator = () => {
      const imgRect = img.getBoundingClientRect();
      const widthCm = pxToCm(imgRect.width);
      const heightCm = pxToCm(imgRect.height);
      const displayW = Math.round(widthCm);
      const displayH = Math.round(heightCm);
      sizeIndicator.textContent = `${displayW}×${displayH}cm`;
      const area = Math.max(0, widthCm * heightCm);
      const price = Number((area * PRICE_PER_CM2).toFixed(2));
      priceIndicator.textContent = `R$ ${price.toFixed(2).replace('.', ',')}`;
    };

    // Definir altura inicial em 8 cm e atualizar indicadores quando a imagem carregar
    img.addEventListener('load', () => {
      try {
        const desiredHeightCm = 8;
        const rect = img.getBoundingClientRect();
        const currentHeightCm = Math.max(0.0001, pxToCm(rect.height));
        // Garantir que o alvo esteja dentro dos limites 3–15 cm
        const targetCm = Math.max(MIN_SIZE_CM, Math.min(MAX_SIZE_CM, desiredHeightCm));
        const curScale = parseFloat(getComputedStyle(wrap).getPropertyValue('--scale')) || 1;
        const factor = targetCm / currentHeightCm;
        wrap.style.setProperty('--scale', String(curScale * factor));
      } catch {}
      updateSizeIndicator();
    });
    wrap.updateSizeIndicator = updateSizeIndicator;

    return wrap;
  }

  // Atualiza a espessura do contorno em todas as imagens já adicionadas
  function applyGlobalOutlineThickness(mm = 0.75) {
    const px = mmToPx(mm);
    document.querySelectorAll('.image-wrap').forEach(wrap => {
      wrap.style.setProperty('--outline-px', `${px}px`);
    });
  }

  function showToast(message, timeout = 2200) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    window.clearTimeout(el._tId);
    el._tId = window.setTimeout(() => el.classList.remove('show'), timeout);
  }

  // Adicionar todas as imagens carregadas ao carrinho com preço por cm²
  function addAllImagesToCart() {
    try {
      const wraps = Array.from(document.querySelectorAll('.image-wrap'));
      if (wraps.length === 0) {
        showToast('Adicione uma imagem antes de enviar ao carrinho.');
        return;
      }

      const cart = JSON.parse(localStorage.getItem('emojiCart') || '[]');
      let added = 0;
      let sum = 0;

      wraps.forEach((wrap, idx) => {
        const img = wrap.querySelector('.user-image');
        if (!img) return;
        const r = img.getBoundingClientRect();
        const widthCm = pxToCm(r.width);
        const heightCm = pxToCm(r.height);
        const area = widthCm * heightCm; // cm²
        const unitPrice = Number((area * PRICE_PER_CM2).toFixed(2));
        // Thumb persistente para o review no carrinho
        const thumbDataUrl = makeThumbDataUrl(img, 220);
        const item = {
          id: Date.now() + idx,
          type: 'custom',
          name: 'Imagem personalizada',
          displayUrl: thumbDataUrl,
          sizeCm: { width: Number(widthCm.toFixed(2)), height: Number(heightCm.toFixed(2)) },
          areaCm2: Number(area.toFixed(2)),
          unitPrice,
          quantity: 1,
          total: unitPrice,
        };
        cart.push(item);
        added += 1;
        sum += unitPrice;
      });

      localStorage.setItem('emojiCart', JSON.stringify(cart));
      window.dispatchEvent(new Event('cart-updated'));
      showToast(`${added} imagem(ns) adicionada(s). Total R$ ${sum.toFixed(2).replace('.', ',')}`);
    } catch (e) {
      console.error(e);
      showToast('Falha ao adicionar ao carrinho.');
    }
  }

  // Verificar se fileInput existe antes de adicionar listener
  if (fileInput) {
    // Suprimir cliques/ponteiros globais por curto período após retorno do diálogo
    let suppressUntil = 0;
    const suppressHandler = (e) => {
      if (Date.now() < suppressUntil) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    window.addEventListener('click', suppressHandler, true);
    window.addEventListener('pointerup', suppressHandler, true);
    window.addEventListener('mouseup', suppressHandler, true);
    // Ao recuperar o foco da janela depois do diálogo, suprimir por um instante
    window.addEventListener('focus', () => {
      if (pickerOpen) {
        pickerOpen = false;
        suppressUntil = Date.now() + 1000;
      }
    });

    fileInput.addEventListener('change', async () => {
    // Ativa cooldown imediato para evitar reabertura acidental ao voltar do diálogo
    pickerRecentlyClosed = true;
    pickerOpen = false;
    suppressUntil = Date.now() + 1500;
    const files = Array.from(fileInput.files || []);
    if (files.length === 0) return;

    // Número atual de imagens
    const existing = gallery.querySelectorAll('.image-wrap').length;
    const remaining = Math.max(0, 10 - existing);
    // Remover arquivos já adicionados anteriormente
    const deduped = files.filter(f => {
      try {
        const k = fileKey(f);
        if (loadedFileKeys.has(k)) return false;
        loadedFileKeys.add(k);
        return true;
      } catch {
        return true;
      }
    });
    const useFiles = deduped.slice(0, remaining);

    for (let i = 0; i < useFiles.length; i++) {
      const file = useFiles[i];
      const originalUrl = URL.createObjectURL(file);
      lastObjectUrl = originalUrl;
      const result = await processImageVariants(originalUrl, 400, false);
      let displayUrl = originalUrl;
      // Preferir SEM contorno no PNG; contorno será aplicado via CSS quando CT estiver on
      if (result.processed) displayUrl = result.noOutlineUrl || result.outlineUrl || originalUrl;
      const wrap = createImageWrap(originalUrl, displayUrl, existing + i, !!result.processed, result);
      gallery.appendChild(wrap);
    }

    if (files.length > remaining) {
      showToast(`Limite de 10 imagens. Adicionadas apenas ${useFiles.length}.`);
    } else if (deduped.length < files.length) {
      showToast('Algumas imagens repetidas foram ignoradas.');
    }
    // Evitar reabrir seletor automaticamente em alguns navegadores
    try { fileInput.value = ''; fileInput.blur(); } catch {}
    openingPicker = false;
    // Desativa cooldown após pequeno intervalo
    setTimeout(() => { pickerRecentlyClosed = false; }, 1500);
  });
  }

  // Arrastar: clicar/segurar/arrastar a imagem pela página
  let dragging = false;
  let startX = 0, startY = 0;
  let originX = 0, originY = 0;
  let activeWrap = null;
  let zCounter = 1;

  // Parse helpers para pegar valores atuais das variáveis CSS
  const getCurrentDrag = (el) => {
    const styles = getComputedStyle(el);
    const dx = parseFloat(styles.getPropertyValue('--drag-x')) || 0;
    const dy = parseFloat(styles.getPropertyValue('--drag-y')) || 0;
    return { dx, dy };
  };

  const setDrag = (el, dx, dy) => {
    el.style.setProperty('--drag-x', `${dx}px`);
    el.style.setProperty('--drag-y', `${dy}px`);
  };

  const onPointerDown = (e) => {
    if (e.target.closest('.close-btn')) return; // não iniciar arrasto ao clicar no fechar
    const wrap = e.target.closest('.image-wrap');
    if (!wrap) return;
    dragging = true;
    activeWrap = wrap;
    activeWrap.classList.add('dragging');
    activeWrap.style.zIndex = String(++zCounter);
    const { dx, dy } = getCurrentDrag(activeWrap);
    originX = dx; originY = dy;
    startX = e.clientX; startY = e.clientY;
    try { activeWrap.setPointerCapture(e.pointerId); } catch {}
  };

  const onPointerMove = (e) => {
    if (!dragging || !activeWrap) return;
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;
    setDrag(activeWrap, originX + deltaX, originY + deltaY);
  };

  const onPointerUp = (e) => {
    if (!dragging || !activeWrap) return;
    dragging = false;
    activeWrap.classList.remove('dragging');
    try { activeWrap.releasePointerCapture(e.pointerId); } catch {}
    activeWrap = null;
  };

  // Fechar imagem
  if (gallery) {
    gallery.addEventListener('click', (e) => {
    const btn = e.target.closest('.close-btn');
    if (!btn) return;
    e.stopPropagation();
    const wrap = btn.closest('.image-wrap');
    if (!wrap) return;
    const url = wrap.dataset.objurl;
    const pNo = wrap.dataset.processedNo;
    const pWith = wrap.dataset.processedWith;
    if (url) { try { URL.revokeObjectURL(url); } catch {} }
    if (pNo && pNo !== url) { try { URL.revokeObjectURL(pNo); } catch {} }
    if (pWith && pWith !== url) { try { URL.revokeObjectURL(pWith); } catch {} }
    if (activeWrap === wrap) {
      dragging = false;
      activeWrap = null;
    }
    wrap.remove();
    });

    // Evitar início de arrasto ao usar controles
    gallery.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.ctrl-btn')) {
      e.stopPropagation();
      return; // não inicia arrasto
    }
    }, true);

    // Ações dos controles
    gallery.addEventListener('click', async (e) => {
    const wrap = e.target.closest('.image-wrap');
    if (!wrap) return;
    const img = wrap.querySelector('.user-image');
    if (!img) return;

    // Zoom: cada clique ajusta ±1cm no MAIOR lado (3–15cm)
      if (e.target.closest('.btn-zoom-in')) {
        const cur = parseFloat(getComputedStyle(wrap).getPropertyValue('--scale')) || 1;
        const imgRect = img.getBoundingClientRect();
        const widthCm = pxToCm(imgRect.width);
        const heightCm = pxToCm(imgRect.height);
        const curMaxCm = Math.max(widthCm, heightCm);
        const targetMaxCm = Math.min(MAX_SIZE_CM, curMaxCm + 1);
        if (targetMaxCm === curMaxCm) return; // já no limite
        const factor = targetMaxCm / curMaxCm;
        const next = cur * factor;
        wrap.style.setProperty('--scale', String(next));
        if (wrap.updateSizeIndicator) wrap.updateSizeIndicator();
        return;
      }
      if (e.target.closest('.btn-zoom-out')) {
        const cur = parseFloat(getComputedStyle(wrap).getPropertyValue('--scale')) || 1;
        const imgRect = img.getBoundingClientRect();
        const widthCm = pxToCm(imgRect.width);
        const heightCm = pxToCm(imgRect.height);
        const curMaxCm = Math.max(widthCm, heightCm);
        const targetMaxCm = Math.max(MIN_SIZE_CM, curMaxCm - 1);
        if (targetMaxCm === curMaxCm) return; // já no limite
        const factor = targetMaxCm / curMaxCm;
        const next = cur * factor;
        wrap.style.setProperty('--scale', String(next));
        if (wrap.updateSizeIndicator) wrap.updateSizeIndicator();
        return;
      }

    // Toggle fundo
    if (e.target.closest('.btn-bg')) {
      const cur = wrap.dataset.bg === 'on' ? 'on' : 'off';
      if (cur === 'on') {
        // restaurar original
        img.src = wrap.dataset.objurl;
        img.classList.remove('processed');
        wrap.dataset.bg = 'off';
        wrap.dataset.ct = 'off';
        // Atualizar indicador após mudança de imagem
        setTimeout(() => {
          if (wrap.updateSizeIndicator) wrap.updateSizeIndicator();
        }, 50);
      } else {
        // aplicar processamento (force=true para permitir sob demanda)
        if (!wrap.dataset.processedNo && !wrap.dataset.processedWith) {
          const result = await processImageVariants(wrap.dataset.objurl, 400, true);
          if (result.noOutlineUrl) wrap.dataset.processedNo = result.noOutlineUrl;
          if (result.outlineUrl) wrap.dataset.processedWith = result.outlineUrl;
        }
        // Usar sempre a versão SEM contorno e aplicar contorno via CSS (CT)
        const useUrl = wrap.dataset.processedNo || wrap.dataset.processedWith || wrap.dataset.objurl;
        if (useUrl) {
          img.src = useUrl;
          img.classList.add('processed');
          wrap.dataset.bg = 'on';
          // Atualizar indicador após mudança de imagem
          setTimeout(() => {
            if (wrap.updateSizeIndicator) wrap.updateSizeIndicator();
          }, 50);
        }
      }
      return;
    }

    // Toggle contorno: sem silhueta via CSS border; com silhueta troca PNG
    if (e.target.closest('.btn-ct')) {
      const turningOn = wrap.dataset.ct !== 'on';
      if (wrap.dataset.bg !== 'on') {
        // Fundo intacto: apenas liga/desliga borda via CSS
        wrap.dataset.ct = turningOn ? 'on' : 'off';
        return;
      }
      // Fundo removido: ao ligar CT, reprocessa com force=true para garantir espessura atual
      if (turningOn) {
        const result = await processImageVariants(wrap.dataset.objurl, 400, true);
        if (result.noOutlineUrl) wrap.dataset.processedNo = result.noOutlineUrl;
        if (result.outlineUrl) wrap.dataset.processedWith = result.outlineUrl;
      } else if (!wrap.dataset.processedNo) {
        // Garantir que existe a variante sem contorno ao desligar
        const result = await processImageVariants(wrap.dataset.objurl, 400, true);
        if (result.noOutlineUrl) wrap.dataset.processedNo = result.noOutlineUrl;
        if (result.outlineUrl) wrap.dataset.processedWith = result.outlineUrl;
      }
      const targetUrl = turningOn ? (wrap.dataset.processedWith || wrap.dataset.processedNo || wrap.dataset.objurl)
                                  : (wrap.dataset.processedNo || wrap.dataset.objurl);
      if (targetUrl) img.src = targetUrl;
      img.classList.add('processed');
      wrap.dataset.ct = turningOn ? 'on' : 'off';
      setTimeout(() => { if (wrap.updateSizeIndicator) wrap.updateSizeIndicator(); }, 50);
      return;
    }
    });
  }

  // Verificar se gallery existe antes de adicionar listeners
  if (gallery) {
    gallery.addEventListener('pointerdown', onPointerDown);
    gallery.addEventListener('pointermove', onPointerMove);
    gallery.addEventListener('pointerup', onPointerUp);
    gallery.addEventListener('pointercancel', onPointerUp);
  }

  // Aplica a redução para imagens existentes ao carregar o script
  applyGlobalOutlineThickness(0.75);

  // Listener do botão Adicionar ao Carrinho
  if (addToCartBtn) {
    addToCartBtn.addEventListener('click', addAllImagesToCart);
  }
})();
// Efeito de corações no banner "Eles já estão" (likes subindo e desaparecendo)
document.addEventListener('DOMContentLoaded', () => {
  try {
    const banner = document.querySelector('.mural-banner');
    if (!banner) return;

    // Camada para os corações (não atrapalha o clique)
    const layer = document.createElement('div');
    layer.className = 'mural-hearts';
    layer.setAttribute('aria-hidden', 'true');
    banner.appendChild(layer);

    const heartImages = [
      'assets/EMOJIS/red-heart_2764-fe0f.png',
      'assets/EMOJIS/pink-heart_1fa77.png',
      'assets/EMOJIS/two-hearts_1f495.png',
      'assets/EMOJIS/yellow-heart_1f49b.png',
      'assets/EMOJIS/blue-heart_1f499.png'
    ];

    const spawnHeart = () => {
      const img = document.createElement('img');
      img.className = 'heart';
      img.alt = '';
      img.src = heartImages[Math.floor(Math.random() * heartImages.length)];

      // Distribuir próximo ao centro da imagem
      const offsetX = (Math.random() * 140) - 70; // -70px..70px
      const size = Math.floor(12 + Math.random() * 16); // 12..28px
      const duration = Math.floor(1400 + Math.random() * 900); // 1400..2300ms

      img.style.left = `${offsetX}px`;
      img.style.width = `${size}px`;
      img.style.height = `${size}px`;
      img.style.animationDuration = `${duration}ms`;

      layer.appendChild(img);
      img.addEventListener('animationend', () => { img.remove(); });
      // Remoção de segurança
      setTimeout(() => { img.remove(); }, duration + 200);
    };

    // Emissão contínua, leve
    const interval = setInterval(spawnHeart, 700);

    // Toque extra ao passar o mouse
    banner.addEventListener('mouseenter', () => {
      spawnHeart(); spawnHeart();
    });

    // Parar se o banner for removido
    const obs = new MutationObserver(() => {
      if (!document.contains(banner)) {
        clearInterval(interval);
        obs.disconnect();
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });
  } catch (err) {
    // Silencioso: não quebrar outras funcionalidades
  }
});

// Card de Emojis: popular lista e sincronizar altura com o avatar
document.addEventListener('DOMContentLoaded', () => {
  try {
    const avatarImg = document.querySelector('.top-avatar img');
    const emojiCard = document.getElementById('emojiCard');
    const emojiList = document.getElementById('emojiList');
    if (!emojiCard || !emojiList) return;

    const emojiFiles = [
      'assets/EMOJIS/red-heart_2764-fe0f.png',
      'assets/EMOJIS/yellow-heart_1f49b.png',
      'assets/EMOJIS/blue-heart_1f499.png',
      'assets/EMOJIS/pink-heart_1fa77.png',
      'assets/EMOJIS/two-hearts_1f495.png',
      'assets/EMOJIS/star-struck_1f929.png',
      'assets/EMOJIS/thumbs-up_1f44d.png',
      'assets/EMOJIS/dog-face_1f436.png',
      'assets/EMOJIS/cat-face_1f431.png',
      'assets/EMOJIS/rocket_1f680.png',
      'assets/EMOJIS/balloon_1f388.png',
      'assets/EMOJIS/ghost_1f47b.png',
      'assets/EMOJIS/pizza_1f355.png',
      'assets/EMOJIS/wine-glass_1f377.png',
      'assets/EMOJIS/popcorn_1f37f.png',
      'assets/EMOJIS/sunflower_1f33b.png',
      'assets/EMOJIS/eyes_1f440.png',
      'assets/EMOJIS/party-popper_1f389.png',
      'assets/EMOJIS/rainbow_1f308.png',
      'assets/EMOJIS/face-with-tears-of-joy_1f602.png',
      'assets/EMOJIS/grinning-face_1f600.png'
    ];

    const populateList = () => {
      try {
        emojiList.innerHTML = '';
        emojiFiles.forEach((src) => {
          const li = document.createElement('li');
          const img = document.createElement('img');
          img.src = src; img.alt = '';
          li.appendChild(img);
          emojiList.appendChild(li);
        });
      } catch {}
    };

    const syncHeight = () => {
      try {
        if (!avatarImg) return;
        const linkEl = document.querySelector('.top-avatar-link') || avatarImg;
        const rect = linkEl.getBoundingClientRect();
        const h = Math.round(avatarImg.getBoundingClientRect().height);
        emojiCard.style.setProperty('--emoji-card-h', `${h}px`);
        emojiCard.style.maxHeight = `${h}px`;
        // Altura do card sincronizada; posição permanece fixa via CSS
      } catch {}
    };

    populateList();
    if (avatarImg) {
      if (avatarImg.complete) syncHeight();
      else avatarImg.addEventListener('load', syncHeight, { once: true });
    }
    window.addEventListener('resize', () => syncHeight());
  } catch {}
});